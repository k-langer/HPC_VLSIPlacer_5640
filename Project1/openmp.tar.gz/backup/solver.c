#include "netlist.h"
#include "common.h"
//TODO: Implement numeric solver to get future GPU speedup 
gate_t ** solver_solve(layout_t * layout) {
    return NULL;
}
